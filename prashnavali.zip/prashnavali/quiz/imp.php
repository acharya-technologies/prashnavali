<?php
$con = mysqli_connect("localhost", "k1n9", "k1n9", "prashnavali");
// $con = mysqli_connect("localhost", "epmyrhid_k1n9", "th15!s0mk4rkulk4rN1", "epmyrhid_quiz");
$tbl_usr = 'users';
$tbl_que = 'question';
$tbl_ans = 'answers';
$tbl_login = 'login';
$website = "http://localhost/quiz";
// $title = "प्रश्नावली";
$title = "Quizzeled";
?>
